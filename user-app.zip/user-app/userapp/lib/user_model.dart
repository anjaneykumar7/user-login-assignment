class User {
  String name;
  String type;
  int id;

  User({required this.id, required this.name, required this.type});
}
